document.addEventListener("DOMContentLoaded", () => {
  const toggleButton = document.getElementById("toggleDarkMode");

  toggleButton.addEventListener("click", () => {
    document.documentElement.classList.toggle("dark-mode");
  });
});
