export async function cargarDatos() {
  const [sectores, rutas, condiciones] = await Promise.all([
    fetch('data/sectores.json').then(res => res.json()),
    fetch('data/rutas.json').then(res => res.json()),
    fetch('data/condiciones.json').then(res => res.json())
  ]);
  return { sectores, rutas, condiciones };
}