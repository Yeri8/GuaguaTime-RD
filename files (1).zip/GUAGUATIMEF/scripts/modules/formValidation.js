export function validarFormulario(origen, destino) {
  return origen !== destino && origen && destino;
}