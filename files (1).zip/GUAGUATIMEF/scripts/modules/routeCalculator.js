export function calcularRuta(ruta, condicionesActivas) {
  let tiempoTotal = ruta.tramos.reduce((acc, tramo) => acc + tramo.tiempo_min, 0);
  let costoTotal = ruta.tramos.reduce((acc, tramo) => acc + tramo.costo, 0);

  condicionesActivas.forEach(cond => {
    tiempoTotal *= (1 + cond.tiempo_pct / 100);
    costoTotal += cond.costo_extra;
  });

  return {
    ...ruta,
    tiempoTotal: Math.round(tiempoTotal),
    costoTotal
  };
}