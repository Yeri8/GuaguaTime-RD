export function guardarFavorita(ruta) {
  const favoritas = JSON.parse(localStorage.getItem('favoritas')) || [];
  favoritas.push(ruta);
  localStorage.setItem('favoritas', JSON.stringify(favoritas));
  alert('Ruta guardada como favorita.');
}