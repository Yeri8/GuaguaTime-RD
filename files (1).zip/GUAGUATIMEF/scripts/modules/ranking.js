export function aplicarRanking(rutas, criterio = 'tiempoTotal') {
  return rutas.sort((a, b) => a[criterio] - b[criterio]);
}