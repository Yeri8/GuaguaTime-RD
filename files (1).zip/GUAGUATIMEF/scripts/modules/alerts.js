export function mostrarAlertas(condiciones) {
  const contenedor = document.getElementById('alertsList');
  condiciones.forEach(cond => {
    const li = document.createElement('li');
    li.className = 'alert';
    li.textContent = `⚠️ ${cond.nombre} activa`;
    contenedor.appendChild(li);
  });
}