import { cargarDatos } from './modules/dataLoader.js';
import { calcularRuta } from './modules/routeCalculator.js';
import { aplicarRanking } from './modules/ranking.js';
import { mostrarAlertas } from './modules/alerts.js';
import { guardarFavorita } from './modules/favorites.js';
import { validarFormulario } from './modules/formValidation.js';
import { debounce } from './modules/debounce.js';

document.addEventListener('DOMContentLoaded', async () => {
  const { sectores, rutas, condiciones } = await cargarDatos();

  // Llenar selects
  const originSelect = document.getElementById('origin');
  const destinationSelect = document.getElementById('destination');

  sectores.forEach(sector => {
    const option1 = document.createElement('option');
    option1.value = sector.id;
    option1.textContent = sector.nombre;
    originSelect.appendChild(option1);

    const option2 = document.createElement('option');
    option2.value = sector.id;
    option2.textContent = sector.nombre;
    destinationSelect.appendChild(option2);
  });

  // Mostrar alertas iniciales
  mostrarAlertas(condiciones);

  // Obtener condiciones activas desde checkboxes
  function obtenerCondicionesActivas() {
    const seleccionadas = Array.from(document.querySelectorAll('input[name="condiciones"]:checked'))
      .map(cb => cb.value);
    return condiciones.filter(cond => seleccionadas.includes(cond.id));
  }

  // Mostrar resultados completos por ruta
  function mostrarResultadosCompletos(rutas) {
    const container = document.getElementById('resultsContainer');
    container.innerHTML = '';

    rutas.forEach(r => {
      const card = document.createElement('div');
      card.className = 'result-card';

      let detalles = `
        <div class="result-card__header">Ruta ${r.id}</div>
        <div class="result-card__details">
          <strong>Origen:</strong> ${r.origen}<br>
          <strong>Destino:</strong> ${r.destino}<br>
          <strong>Transbordos:</strong> ${r.transbordos}<br>
          <strong>Opciones de transporte:</strong><br>
      `;

      r.tramos.forEach(t => {
        detalles += `&nbsp;&nbsp;• ${t.medio}: ${t.tiempo_min} min, RD$${t.costo}<br>`;
      });

      detalles += `</div>
        <button onclick='guardarFavorita(${JSON.stringify(r)})'>Guardar</button>
      `;

      card.innerHTML = detalles;
      container.appendChild(card);
    });
  }

  // Manejo del formulario
  document.getElementById('routeForm').addEventListener('submit', (e) => {
    e.preventDefault();
    const origen = originSelect.value;
    const destino = destinationSelect.value;

    if (!validarFormulario(origen, destino)) {
      alert('Selecciona un origen y destino válidos.');
      return;
    }

    const condicionesActivas = obtenerCondicionesActivas();
    const rutasFiltradas = rutas.filter(r => r.origen === origen && r.destino === destino);

    const container = document.getElementById('resultsContainer');
    container.innerHTML = '';

    if (rutasFiltradas.length === 0) {
      container.innerHTML = '<p>No hay rutas disponibles para esta combinación.</p>';
      return;
    }

    const rutasCalculadas = rutasFiltradas.map(r => calcularRuta(r, condicionesActivas));
    const rutasOrdenadas = aplicarRanking(rutasCalculadas);

    mostrarResultadosCompletos(rutasOrdenadas);
  });

  window.guardarFavorita = guardarFavorita;

  // Debounce en campo de búsqueda
  const searchInput = document.getElementById('search');
  if (searchInput) {
    searchInput.addEventListener('input', debounce((e) => {
      const query = e.target.value.trim();
      if (query.length > 2) {
        document.getElementById('routeForm').dispatchEvent(new Event('submit'));
      }
    }, 400));
  }
});