# Guaguas — Grupo 3 (Extras, optimización y entrega)

## Contenido
Este proyecto es una aplicación web ligera que permite:
- Elegir origen y destino entre barrios/sectores dominicanos.
- Obtener rutas estimadas (concho, guagua, motoconcho, carro público) con tiempos y costos.
- Comparar rutas y guardar favoritas en el dispositivo.
- Visualizar alertas (lluvia, hora pico, paro) que afectan estimaciones.
- Funciona 100% en el navegador, sin frameworks ni backends externos. Datos desde archivos locales .json.

## Archivos claves añadidos
- `map/map.svg` — backup del mini-mapa SVG.
- `manifest.json` — PWA manifest.
- `service-worker.js` — service worker para cache básico.
- `i18n/lang.json` — diccionario ES/EN.
- `i18n/i18n.js` — loader i18n.
- `app.js` — lógica principal (mini-mapa, rutas, favoritos, power-save).
- `data/alerts.json` — ejemplo de alertas.
- `README.md` — este archivo.

## Reglas de cálculo (deterministas)
- **Tiempo base de ruta** = suma `time_min` de tramos (en esta implementación se aproxima por tiempo_min estimado).
- **Por cada condición activa**: `tiempo = tiempo * (1 + tiempo_pct/100)`; redondear al minuto.
- **Costo total** = suma de `costo` + suma de `costo_extra` de condiciones.
- **Ranking**: por defecto ordena por tiempo total; el usuario puede alternar (no implementado UI avanzada en esta entrega).

Documentamos las condiciones por defecto:
- lluvia: `tiempo_pct = 30`, `costo_extra = 10`
- hora pico: `tiempo_pct = 20`, `costo_extra = 5`
- paro/strike: `tiempo_pct = 50`, `costo_extra = 20`

## Cómo probar localmente
1. Descarga y extrae el ZIP.
2. Sirve los archivos desde un servidor estático (recomendado `python -m http.server 8000` desde la carpeta del proyecto).
3. Abre `http://localhost:8000` en tu navegador.
4. Registra el Service Worker desde la app (automáticamente intenta registrarlo). Instala la PWA desde el navegador si lo deseas.

## Modo ahorro (power save)
Activa el checkbox "Mode Ahorro" para reducir elementos gráficos (círculos más pequeños y etiquetas ocultas). Ideal para dispositivos con datos limitados.

## Accesibilidad y optimización
- SVG con `aria-label` y elementos `tabindex` para navegabilidad con teclado.
- Estructura semántica simple y contrastes adecuados.
- Para mejores resultados ejecutar Lighthouse y aplicar recomendaciones (optimización de imágenes, preloading, reducing unused JS/CSS).

## Entrega
Se incluye un ZIP listo para subir a GitHub. Si deseas, te lo puedo empaquetar (ya generado en esta sesión) y darte el enlace de descarga.

