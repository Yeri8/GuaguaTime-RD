"use strict";

/*
  Main app:
  - loads sectors list
  - injects SVG mini-map
  - computes deterministic routes using rules provided
  - applies alerts (conditions)
  - saves favorites to localStorage
  - toggles power save and language via i18n
*/

const SECTORS = [
  // Exclusive/modern
  "Piantini","Naco","Evaristo Morales","Bella Vista","Los Cacicazgos","La Esperilla","Serrallés","Mirador Sur","Ensanche Quisqueya","Yolanda Morales",
  // Traditional
  "Villa Juana","Villa Consuelo","Gualey","Los Mina","Simón Bolívar","Capotillo","Las Caobas","Los Ríos","Cristo Rey","La Puya de Arroyo Hondo",
  // Historic
  "Zona Colonial","Gazcue","Ciudad Universitaria (UASD)",
  // Periphery
  "Los Alcarrizos","Pedro Brand","Sabana Perdida","Villa Mella","La Victoria","San Isidro"
];

const CONDITIONS = {
  rain: { key: 'rain', tiempo_pct: 30, costo_extra: 10 },
  peak: { key: 'peak', tiempo_pct: 20, costo_extra: 5 },
  strike: { key: 'strike', tiempo_pct: 50, costo_extra: 20 }
};

// Create simple SVG mini-map: grid of points
function createMiniMap() {
  const w = 600, h = 400;
  const cols = 5;
  const rows = Math.ceil(SECTORS.length / cols);
  const cellW = w/cols;
  const cellH = h/rows;

  const svgns = "http://www.w3.org/2000/svg";
  const svg = document.createElementNS(svgns, "svg");
  svg.setAttribute("width", "100%");
  svg.setAttribute("viewBox", `0 0 ${w} ${h}`);
  svg.setAttribute("id", "mapSvg");
  svg.setAttribute("role","img");
  svg.setAttribute("aria-label","Mini-map of sectors");

  // lines connecting in simple pattern
  for (let r=0; r<rows; r++){
    for (let c=0; c<cols; c++){
      const idx = r*cols + c;
      if (idx >= SECTORS.length) break;
      const x = c*cellW + cellW/2;
      const y = r*cellH + cellH/2;
      // draw circle
      const circ = document.createElementNS(svgns,"circle");
      circ.setAttribute("cx", x);
      circ.setAttribute("cy", y);
      circ.setAttribute("r", 12);
      circ.setAttribute("fill", "#007bff");
      circ.setAttribute("tabindex","0");
      circ.setAttribute("data-idx", idx);
      circ.setAttribute("class","map-stop");
      circ.setAttribute("aria-label", SECTORS[idx]);
      svg.appendChild(circ);

      // label
      const txt = document.createElementNS(svgns,"text");
      txt.setAttribute("x", x + 18);
      txt.setAttribute("y", y + 6);
      txt.textContent = SECTORS[idx];
      txt.setAttribute("font-size","12");
      svg.appendChild(txt);

      // connect to next in same row
      const nextIdx = idx+1;
      if (c < cols-1 && nextIdx < SECTORS.length) {
        const x2 = (c+1)*cellW + cellW/2;
        const y2 = y;
        const line = document.createElementNS(svgns,"line");
        line.setAttribute("x1", x);
        line.setAttribute("y1", y);
        line.setAttribute("x2", x2);
        line.setAttribute("y2", y2);
        line.setAttribute("stroke", "#ccc");
        line.setAttribute("stroke-width", "2");
        svg.appendChild(line);
      }
    }
  }

  return svg;
}

function populateSelects() {
  const o = document.getElementById("origin");
  const d = document.getElementById("destination");
  SECTORS.forEach(s=>{
    const oOpt = document.createElement("option"); oOpt.value = s; oOpt.textContent = s;
    const dOpt = oOpt.cloneNode(true);
    o.appendChild(oOpt); d.appendChild(dOpt);
  });
}

// Simple deterministic route generator (no backend)
function generateRoutes(origin, destination) {
  if (origin === destination) return [];
  // We'll create 3 candidate routes: concho, guagua, motoconcho/car
  // Each route composed of segments with time_min and cost
  const distFactor = Math.abs(SECTORS.indexOf(origin) - SECTORS.indexOf(destination)) + 1;
  const baseTimes = {
    concho: 10 * distFactor,
    guagua: 15 * distFactor,
    motoconcho: 5 * distFactor,
    carro: 12 * distFactor
  };
  const baseCosts = {
    concho: 30 * distFactor,
    guagua: 20 * distFactor,
    motoconcho: 50 * distFactor,
    carro: 60 * distFactor
  };

  const candidates = [
    { mode: 'concho', tiempo_min: baseTimes.concho, costo: baseCosts.concho, transbordos: 1 },
    { mode: 'guagua', tiempo_min: baseTimes.guagua, costo: baseCosts.guagua, transbordos: 2 },
    { mode: 'motoconcho', tiempo_min: baseTimes.motoconcho, costo: baseCosts.motoconcho, transbordos: 0 },
    { mode: 'carro_publico', tiempo_min: baseTimes.carro, costo: baseCosts.carro, transbordos: 0 }
  ];

  // apply deterministic variety: add small random-looking offsets via string hash
  function pseudoOffset(a,b){
    let s = a + '|' + b;
    let h=0; for (let i=0;i<s.length;i++) h = ((h<<5)-h)+s.charCodeAt(i);
    return Math.abs(h)%7; // 0..6
  }
  const offs = pseudoOffset(origin,destination);
  candidates.forEach(c=>{
    c.tiempo_min = Math.round(c.tiempo_min * (1 + (offs/100)));
    c.costo = Math.round(c.costo + (offs));
    c.segments = [
      { name: origin + " → midpoint", time_min: Math.max(1, Math.round(c.tiempo_min*0.5)), cost: Math.round(c.costo*0.4) },
      { name: "midpoint → " + destination, time_min: Math.max(1, Math.round(c.tiempo_min*0.5)), cost: Math.round(c.costo*0.6) }
    ];
  });
  return candidates;
}

// apply conditions (alerts) to a route
function applyConditions(route, activeConditions) {
  let tiempo = route.tiempo_min;
  let costo = route.costo;
  activeConditions.forEach(cond=>{
    tiempo = Math.round(tiempo * (1 + cond.tiempo_pct/100));
    costo = Math.round(costo + cond.costo_extra);
  });
  return { ...route, tiempo_total: tiempo, costo_total: costo };
}

// UI helpers
function renderResults(routes, activeConditions) {
  const ul = document.getElementById("resultsList");
  ul.innerHTML = "";
  routes.forEach(r=>{
    const applied = applyConditions(r, activeConditions);
    const li = document.createElement("li");
    li.className = "route";
    li.innerHTML = `<strong>${t('mode.'+r.mode)}</strong> — ${applied.tiempo_total} min — RD$ ${applied.costo_total} — transbordos: ${r.transbordos}
      <div><button class="favBtn">Favorite</button></div>`;
    ul.appendChild(li);
    li.querySelector(".favBtn").addEventListener("click", ()=> saveFavorite(r));
  });
}

// favorites
function saveFavorite(route) {
  const favs = JSON.parse(localStorage.getItem("guaguas_favs") || "[]");
  favs.push({ route: route, date: new Date().toISOString() });
  localStorage.setItem("guaguas_favs", JSON.stringify(favs));
  alert(t('messages.saved'));
}
function showFavorites() {
  const favs = JSON.parse(localStorage.getItem("guaguas_favs") || "[]");
  const ul = document.getElementById("resultsList");
  ul.innerHTML = "";
  if (favs.length === 0) { ul.innerHTML = "<li>No favorites</li>"; return; }
  favs.forEach(f=>{
    const li = document.createElement("li");
    li.textContent = `${f.route.mode} — ${f.route.tiempo_min} min — RD$ ${f.route.costo} — saved ${new Date(f.date).toLocaleString()}`;
    ul.appendChild(li);
  });
}

// Alerts loader (local)
async function loadAlerts() {
  try {
    const res = await fetch('data/alerts.json');
    const data = await res.json();
    return data.alerts || [];
  } catch(e){
    console.warn("No alerts file:", e);
    return [];
  }
}

function activeConditionsFromAlerts(alerts) {
  // map alerts to conditions objects
  const actives = [];
  alerts.forEach(a=>{
    if (a.type === 'rain') actives.push(CONDITIONS.rain);
    if (a.type === 'peak') actives.push(CONDITIONS.peak);
    if (a.type === 'strike') actives.push(CONDITIONS.strike);
  });
  return actives;
}

function t(key) {
  // simple i18n access
  return window.i18n ? window.i18n.t(key) : key;
}

// Power save mode toggler
function applyPowerSave(enable) {
  const svg = document.getElementById("mapSvg");
  if (!svg) return;
  if (enable) {
    // reduce circle radius and remove labels
    svg.querySelectorAll("circle").forEach(c=> c.setAttribute("r","8"));
    svg.querySelectorAll("text").forEach(t=> t.setAttribute("display","none"));
  } else {
    svg.querySelectorAll("circle").forEach(c=> c.setAttribute("r","12"));
    svg.querySelectorAll("text").forEach(t=> t.removeAttribute("display"));
  }
}

// Initialization
async function init() {
  populateSelects();

  // inject svg
  const svg = createMiniMap();
  document.getElementById("svgWrap").appendChild(svg);

  // click on svg stops to choose origin/destination
  document.querySelectorAll(".map-stop").forEach(el=>{
    el.addEventListener("click", ()=>{
      const idx = parseInt(el.dataset.idx,10);
      const name = SECTORS[idx];
      // if origin empty set origin else set destination
      const o = document.getElementById("origin");
      const d = document.getElementById("destination");
      if (!o.value) o.value = name;
      else d.value = name;
    });
    el.addEventListener("keydown", (e)=>{
      if (e.key === "Enter") el.click();
    });
  });

  // load alerts and render
  const alerts = await loadAlerts();
  const alertsList = document.getElementById("alertsList");
  alertsList.innerHTML = "";
  alerts.forEach(a=>{
    const li = document.createElement("li");
    li.className = "alert alert--" + a.type;
    li.textContent = a.title + " — " + a.detail;
    alertsList.appendChild(li);
  });

  // display calc rules
  document.getElementById("calcRules").textContent = "Rules: tiempo base = sum of tramo times. For each active condition time = time * (1 + tiempo_pct/100). Cost = sum cost + costo_extra.";

  // events
  document.getElementById("findBtn").addEventListener("click", ()=>{
    const o = document.getElementById("origin").value;
    const d = document.getElementById("destination").value;
    const routes = generateRoutes(o,d);
    const activeConds = activeConditionsFromAlerts(alerts);
    renderResults(routes, activeConds);
  });

  document.getElementById("saveFavBtn").addEventListener("click", ()=>{
    const o = document.getElementById("origin").value;
    const d = document.getElementById("destination").value;
    const routes = generateRoutes(o,d);
    if (routes.length) saveFavorite(routes[0]);
  });

  document.getElementById("showFavsBtn").addEventListener("click", showFavorites);

  // power save toggle
  const ps = document.getElementById("powerSave");
  ps.addEventListener("change", (e)=> applyPowerSave(e.target.checked));

  // language toggle
  const langToggle = document.getElementById("langToggle");
  langToggle.addEventListener("click", (e)=> {
    e.preventDefault();
    window.i18n && window.i18n.toggle();
  });

  // service worker register
  if ('serviceWorker' in navigator){
    navigator.serviceWorker.register('service-worker.js').then(()=> {
      console.log("SW registered");
    }).catch(()=> console.warn("SW failed"));
  }

  // apply default i18n
  window.i18n && window.i18n.applyToDocument();
}

window.addEventListener("DOMContentLoaded", init);
