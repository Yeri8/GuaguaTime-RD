// app.js
import { loadAllData } from './modules/data-loader.js';
import { RouteCalculator } from './modules/calc.js';
import * as storage from './modules/storage.js';
import { debounce, fmtMinutes } from './modules/utils.js';
import { validateOriginDestination } from './modules/validators.js';

let DATA = null;
let calc = null;
let activeConditions = []; // ids

async function init(){
  try {
    DATA = await loadAllData('/data');
    calc = new RouteCalculator(DATA.rutas, DATA.condiciones);
    populateSelects(DATA.sectores);
    renderConditions(DATA.condiciones);
    bindEvents();
    renderFavorites();
    console.log('App inicializada', DATA);
  } catch (e) {
    console.error('Error cargando datos', e);
    alert('Error cargando datos. Asegúrate de servir el proyecto con un servidor local.');
  }
}

function populateSelects(sectors){
  const from = document.getElementById('from');
  const to = document.getElementById('to');
  if(!from || !to) return;
  from.innerHTML = '<option value="">-- Origen --</option>';
  to.innerHTML = '<option value="">-- Destino --</option>';
  for(const s of sectors){
    const o1 = document.createElement('option');
    o1.value = s.id; o1.textContent = s.name; from.appendChild(o1);
    const o2 = o1.cloneNode(true); to.appendChild(o2);
  }
}

function renderConditions(conds){
  const panel = document.getElementById('conditions');
  if(!panel) return;
  panel.innerHTML = '';
  conds.forEach(c => {
    const id = `cond_${c.id}`;
    const label = document.createElement('label');
    label.style.marginRight = '10px';
    label.innerHTML = `<input type="checkbox" id="${id}" data-id="${c.id}"> ${c.label_es || c.id}`;
    panel.appendChild(label);
    label.querySelector('input').addEventListener('change', (ev) => {
      const cid = ev.target.dataset.id;
      if(ev.target.checked) {
        if(!activeConditions.includes(cid)) activeConditions.push(cid);
      } else {
        activeConditions = activeConditions.filter(x => x !== cid);
      }
    });
  });
}

function bindEvents(){
  const searchBtn = document.getElementById('search');
  const from = document.getElementById('from');
  const to = document.getElementById('to');
  const sort = document.getElementById('sort');

  if(searchBtn) searchBtn.addEventListener('click', onSearch);
  // si cambian selects podemos re-buscar (debounce)
  const onChange = debounce(() => { /* opcional: auto-search */ }, 250);
  if(from) from.addEventListener('change', onChange);
  if(to) to.addEventListener('change', onChange);

  if(sort) sort.addEventListener('change', () => {
    const last = window.__LAST_RESULTS || [];
    const sorted = calc.sort(last, sort.value || 'time');
    renderResults(sorted);
  });

  // delegación para eliminar favoritos
  const favRoot = document.getElementById('favorites');
  if(favRoot){
    favRoot.addEventListener('click', (ev) => {
      const btn = ev.target.closest('button[data-action]');
      if(!btn) return;
      const action = btn.dataset.action;
      const id = btn.dataset.id;
      if(action === 'remove') {
        storage.removeFavorite(id);
        renderFavorites();
      }
    });
  }
}

function onSearch(){
  const fromVal = document.getElementById('from')?.value;
  const toVal = document.getElementById('to')?.value;
  const v = validateOriginDestination(fromVal, toVal);
  if(!v.ok) { alert(v.msg); return; }

  // filtrado simple: tomamos rutas que contengan el origen o destino en sus segmentos
  const matches = DATA.rutas.filter(route => {
    const stops = route.segments.flatMap(s => [s.from, s.to]);
    return stops.includes(fromVal) || stops.includes(toVal);
  });

  // calcular todas con condiciones activas y filtrar por matches
  const computed = calc.computeAll(activeConditions);
  const results = computed.filter(r => matches.find(m => m.id === r.id));
  const sorted = calc.sort(results, 'time');
  window.__LAST_RESULTS = sorted;
  renderResults(sorted);
}

function renderResults(list){
  const root = document.getElementById('results');
  if(!root) return;
  root.innerHTML = '';
  if(!list.length){ root.textContent = 'No se encontraron rutas.'; return; }
  list.forEach(r => {
    const card = document.createElement('div');
    card.className = 'route-card';
    card.innerHTML = `
      <h3>${r.name}</h3>
      <p>Tiempo estimado: <strong>${fmtMinutes(r.time)}</strong> • Costo: <strong>RD$${r.cost}</strong></p>
      <p>Transbordos: ${r.transfers}</p>
      <div><button class="btn-save" data-id="${r.id}">Guardar favorita</button></div>
    `;
    root.appendChild(card);
    card.querySelector('.btn-save').addEventListener('click', () => {
      storage.saveFavorite({ id: r.id, name: r.name, time: r.time, cost: r.cost });
      renderFavorites();
    });
  });
}

function renderFavorites(){
  const fRoot = document.getElementById('favorites');
  if(!fRoot) return;
  const favs = storage.listFavorites();
  fRoot.innerHTML = '';
  if(!favs.length) { fRoot.textContent = 'No hay rutas favoritas.'; return; }
  favs.forEach(f => {
    const div = document.createElement('div');
    div.className = 'fav-item';
    div.innerHTML = `<strong>${f.name}</strong> — ${fmtMinutes(f.time)} — RD$${f.cost} 
      <button data-action="remove" data-id="${f.id}">Eliminar</button>`;
    fRoot.appendChild(div);
  });
}

document.addEventListener('DOMContentLoaded', init);
