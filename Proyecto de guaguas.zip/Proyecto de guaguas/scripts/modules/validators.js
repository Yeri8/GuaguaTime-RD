// validators.js
export function validateOriginDestination(from, to){
  if(!from || !to) return { ok:false, msg: 'Seleccione origen y destino.' };
  if(from === to) return { ok:false, msg: 'Origen y destino no pueden ser iguales.' };
  return { ok:true };
}
