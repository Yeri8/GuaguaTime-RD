// storage.js
const KEY = 'gt_favorites_v1';

export function listFavorites(){
  try {
    return JSON.parse(localStorage.getItem(KEY) || '[]');
  } catch(e){
    console.warn('Error parseando favoritos', e);
    return [];
  }
}

export function saveFavorite(route){
  const arr = listFavorites();
  if(!arr.find(r => r.id === route.id)){
    arr.push(route);
    localStorage.setItem(KEY, JSON.stringify(arr));
  }
}

export function removeFavorite(routeId){
  const arr = listFavorites().filter(r => r.id !== routeId);
  localStorage.setItem(KEY, JSON.stringify(arr));
}

export function isFavorite(routeId){
  return !!listFavorites().find(r => r.id === routeId);
}
