// utils.js
export function debounce(fn, wait = 300){
  let t;
  return (...args) => {
    clearTimeout(t);
    t = setTimeout(() => fn(...args), wait);
  };
}

export function fmtMinutes(m){
  if (isNaN(m)) return '-';
  m = Math.round(m);
  if (m < 60) return `${m} min`;
  const h = Math.floor(m/60);
  const mm = m % 60;
  return mm ? `${h}h ${mm}m` : `${h}h`;
}
