// calc.js
// Clase sencilla que implementa las reglas de cálculo indicadas

export class RouteCalculator {
  constructor(routes = [], conditions = []) {
    this.routes = routes || [];
    // mapa de condiciones por id para acceso rápido
    this.conditionsMap = Object.fromEntries((conditions || []).map(c => [c.id, c]));
  }

  // calcula una ruta individual con condiciones activas (array de ids)
  compute(route, activeConditionIds = []) {
    const segments = route.segments || [];
    const timeBase = segments.reduce((sum, seg) => sum + (Number(seg.time_min) || 0), 0);
    const costBase = segments.reduce((sum, seg) => sum + (Number(seg.cost) || 0), 0);

    let time = timeBase;
    let extraCost = 0;
    for(const cid of (activeConditionIds || [])){
      const c = this.conditionsMap[cid];
      if(!c) continue;
      const pct = Number(c.tiempo_pct || 0);
      time = time * (1 + pct / 100); // aplicar cada condición secuencialmente
      extraCost += Number(c.costo_extra || 0);
    }

    const timeRounded = Math.round(time); // redondear al minuto
    const costTotal = costBase + extraCost;

    return {
      id: route.id,
      name: route.name,
      transfers: route.transfers || 0,
      timeBase,
      time: timeRounded,
      cost: costTotal,
      segments
    };
  }

  // calcular todas las rutas
  computeAll(activeConditionIds = []) {
    return (this.routes || []).map(r => this.compute(r, activeConditionIds));
  }

  // ordenar resultados por 'time' | 'cost' | 'transfers'
  sort(results = [], mode = 'time') {
    const arr = results.slice();
    if(mode === 'time') return arr.sort((a,b) => a.time - b.time);
    if(mode === 'cost') return arr.sort((a,b) => a.cost - b.cost);
    if(mode === 'transfers') return arr.sort((a,b) => a.transfers - b.transfers);
    return arr;
  }
}
