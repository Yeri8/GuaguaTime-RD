// data-loader.js
// funciones simples para cargar JSON locales

export async function loadJSON(path){
  const res = await fetch(path, { cache: 'no-cache' });
  if(!res.ok) throw new Error(`Error cargando ${path}: ${res.status}`);
  return res.json();
}

export async function loadAllData(base = '/data'){
  // cargamos sectores, rutas y condiciones
  const [sectores, rutas, condiciones] = await Promise.all([
    loadJSON(`${base}/sectores.json`),
    loadJSON(`${base}/rutas.json`),
    loadJSON(`${base}/condiciones.json`)
  ]);
  return { sectores, rutas, condiciones };
}
